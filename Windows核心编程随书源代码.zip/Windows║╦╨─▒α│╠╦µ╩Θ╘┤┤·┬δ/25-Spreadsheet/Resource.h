//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Spreadsheet.rc
//
#define IDC_STATIC              (-1)     // all static controls
#define IDD_SPREADSHEET                 1
#define IDC_LOG                         101
#define IDI_SPREADSHEET                 102
#define IDC_ROW                         1001
#define IDC_COLUMN                      1002
#define IDC_COLUMN2                     1003
#define IDC_VALUE                       1003
#define IDC_READCELL                    1004
#define IDC_WRITECELL                   1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
