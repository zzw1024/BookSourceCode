set -e
cd lab1; make clean; make; cd ..
cd lab2; make clean; make; cd ..
cd lab3; make clean; make; cd ..
cd lab4; make clean; make; cd ..
cd lab5; make clean; make; cd ..
cd lab6; make clean; make; cd ..
cd lab7; make clean; make; cd ..
cd lab8; make clean; make; cd ..
